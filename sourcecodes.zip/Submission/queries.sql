SELECT *
FROM flight
WHERE CURRENT_DATE < flight.departure_date OR (CURRENT_DATE = flight.departure_date AND CURRENT_TIME < departure_time);

SELECT *
FROM flight
WHERE flight.status = 'delayed'

SELECT distinct name
FROM purchases NATURAL JOIN customer

SELECT distinct name
FROM purchases NATURAL JOIN customer
WHERE booking_agent_id IS NOT null

SELECT *
FROM airplane
WHERE airline_name = 'Emirates'